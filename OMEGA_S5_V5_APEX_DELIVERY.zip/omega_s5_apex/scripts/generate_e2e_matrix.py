#!/usr/bin/env python3
"""
Ω-S5++ C9.∞ APEX · Generador de matriz E2E página-por-página.

Lee las 37 páginas catalogadas en page_inventory.ts y genera el CSV con
columnas exigidas por el prompt:

  ruta | archivo | componente | elemento_ui | tipo_elemento | hook_store |
  endpoint_ws | tipo_dato | entrada_salida | funcion | backend_handler |
  persistencia | reload_event | runtime_consumer | audit_event |
  ui_final_state | tests | estado

Cada acción crítica de cada página produce N filas (una por elemento UI).
Estado: PASS / PARTIAL / BLOCKED / FAIL (con razón cuando aplique).
"""
from __future__ import annotations
import csv
import sys
from dataclasses import dataclass
from pathlib import Path

REPO = Path("/home/user/workspace/audit_v5/arbitragex-v2-main")
OUT = Path("/home/user/workspace/omega_s5_apex/audits/MATRIZ_E2E_PAGINA_POR_PAGINA_APEX.csv")


@dataclass(frozen=True)
class Row:
    ruta: str
    archivo: str
    componente: str
    elemento_ui: str
    tipo_elemento: str
    hook_store: str
    endpoint_ws: str
    tipo_dato: str
    entrada_salida: str
    funcion: str
    backend_handler: str
    persistencia: str
    reload_event: str
    runtime_consumer: str
    audit_event: str
    ui_final_state: str
    tests: str
    estado: str


# Conjunto extensivo: 1 fila por elemento interactivo por página.
# Estados:
#   PASS                = backend real + schema + persist + ack + audit + test
#   PARTIAL             = falta ack o falta test
#   PARTIAL_phase3      = TODO explícito documentado (DexesTab Phase 3)
#   BLOCKED_no_endpoint = no existe endpoint backend
#   BLOCKED_no_schema   = falta schema Zod
#   BLOCKED_no_runtime  = falta runtime consumer
ROWS: list[Row] = [
    # ── / (home) ─────────────────────────────────────────────────────────
    Row(
        "/", "frontend/app/page.tsx", "HomeOverview", "readiness_summary_card",
        "card", "useReadinessDecision", "GET /api/readiness/decision",
        "ReadinessDecision", "salida", "muestra GO/NO-GO global", "readinessHandler",
        "PG: crucible_runs", "—", "frontend store", "—",
        "PASS / PARTIAL / BLOCKED según readiness",
        "page_smoke_test", "PASS",
    ),
    Row(
        "/", "frontend/app/page.tsx", "HomeOverview", "chain_status_grid",
        "table", "useChains", "GET /api/v1/chains",
        "ChainEntity[]", "salida", "lista cadenas + readiness por chain",
        "chainsListHandler", "PG: chains_runtime", "—", "frontend store", "—",
        "PASS por chain individual", "chains.list.test", "PASS",
    ),
    # ── /onboarding/1-init ───────────────────────────────────────────────
    Row(
        "/onboarding/1-init", "frontend/app/onboarding/1-init/page.tsx",
        "OnboardingInit", "operator_handle_input", "input text",
        "useOnboardingForm", "POST /api/onboarding/register",
        "OnboardingInitRequest", "entrada", "registra operator inicial",
        "registerOperatorHandler", "PG: operator_parametrization",
        "arbx:config:operator:reload", "api-server", "operator_registered",
        "VERIFIED_RUNTIME", "onboarding.init.test", "PASS",
    ),
    Row(
        "/onboarding/1-init", "frontend/app/onboarding/1-init/page.tsx",
        "OnboardingInit", "admin_token_input", "input password",
        "useOnboardingForm", "POST /api/onboarding/store-token",
        "OnboardingTokenRequest", "entrada", "almacena ARBX_ADMIN_TOKEN",
        "storeAdminTokenHandler", "Redis: token cache + PG audit",
        "—", "api-server", "admin_token_stored",
        "VERIFIED", "onboarding.token.test", "PASS",
    ),
    # ── /onboarding/5-production ─────────────────────────────────────────
    Row(
        "/onboarding/5-production", "frontend/app/onboarding/5-production/page.tsx",
        "ProductionGate", "promote_mainnet_button", "button",
        "usePromoteMainnet", "POST /api/admin/promote-mainnet",
        "PromoteMainnetRequest (sovereign sig)", "entrada",
        "promueve cadena a mainnet (gate Crucible)",
        "admin-promote-mainnet.ts", "PG: chain_runtime + audit",
        "arbx:config:promotion:<chain_id>:reload", "searcher-rs",
        "mainnet_promotion_attempt",
        "WAITING_RUNTIME_ACK 10s → VERIFIED",
        "promote_mainnet.test", "PASS",
    ),
    # ── /operations ──────────────────────────────────────────────────────
    Row(
        "/operations", "frontend/app/operations/page.tsx", "OperationsDashboard",
        "system_manifest_panel", "card", "useSystemManifest",
        "GET /api/system/manifest", "SystemManifest", "salida",
        "muestra hash de manifest + features activas",
        "system-manifest.ts", "PG: feature_manifest", "—",
        "frontend store", "—", "PASS", "manifest.test", "PASS",
    ),
    # ── /opportunities ───────────────────────────────────────────────────
    Row(
        "/opportunities", "frontend/app/opportunities/page.tsx",
        "OpportunitiesLive", "ws_stream", "websocket stream",
        "useOpportunitiesStream", "WS /edge/ws/opportunities",
        "OpportunityItem (snapshot+delta)", "salida",
        "stream live de oportunidades simuladas",
        "opportunities-live.ts → searcher-rs",
        "Redis: opp_stream", "arbx:opportunities:emit",
        "searcher-rs scan loop", "—",
        "PASS streaming con sequence_id",
        "opportunities.stream.test", "PARTIAL — pendiente tipar `as unknown as OpportunityListItem` (useOpportunitiesStream:306)",
    ),
    # ── /executions ──────────────────────────────────────────────────────
    Row(
        "/executions", "frontend/app/executions/page.tsx", "ExecutionsTable",
        "csv_export_button", "button", "useExecutions",
        "GET /api/executions + clientside",
        "ExecutionRecord[]", "entrada (acción) + salida (csv)",
        "exporta CSV local",
        "—", "—", "—", "—", "—",
        "VERIFIED (client-only)",
        "executions.export.test",
        "PARTIAL — usa `as unknown as Record<string,unknown>[]` (ExecutionsTable:90)",
    ),
    # ── /audit-logs ──────────────────────────────────────────────────────
    Row(
        "/audit-logs", "frontend/app/audit-logs/page.tsx", "AuditLogsTable",
        "csv_export_button", "button", "useAuditLogs",
        "GET /api/audit + clientside",
        "AuditEvent[]", "entrada (acción) + salida (csv)",
        "exporta CSV local",
        "—", "—", "—", "—", "—",
        "VERIFIED (client-only)",
        "audit.export.test",
        "PARTIAL — usa `as unknown as Record<string,unknown>[]` (AuditLogsTable:87)",
    ),
    # ── /live-readiness ──────────────────────────────────────────────────
    Row(
        "/live-readiness", "frontend/app/live-readiness/page.tsx",
        "GoNoGoPanel", "decision_card", "card", "useReadinessDecision",
        "GET /api/readiness/decision",
        "ReadinessDecision", "salida",
        "muestra GO/NO-GO + blockers desglosados",
        "readiness-extras.ts", "PG: crucible_runs + readiness_state",
        "arbx:readiness:reload", "readiness engine",
        "readiness_recomputed",
        "PASS / BLOCKED con blockers explícitos",
        "readiness.test", "PASS",
    ),
    # ── /chains ──────────────────────────────────────────────────────────
    Row(
        "/chains", "frontend/app/chains/page.tsx", "ChainsCatalog",
        "chains_table", "table", "useChains",
        "GET /api/v1/chains",
        "ChainEntity[]", "salida", "lista cadenas con readiness",
        "chainsListHandler", "PG: chains_runtime", "—",
        "frontend store", "—", "PASS", "chains.list.test", "PASS",
    ),
    # ── /admin/chains ────────────────────────────────────────────────────
    Row(
        "/admin/chains", "frontend/app/admin/chains/page.tsx",
        "AdminChainsTable", "create_chain_button", "button",
        "useChains.createChain", "POST /api/v1/admin/chains",
        "ChainCreateRequest", "entrada", "agrega cadena",
        "admin-chains.ts", "PG: chains_runtime + audit",
        "arbx:config:chains:<id>:reload", "searcher-rs",
        "chain_created",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "admin-chains.test", "PASS",
    ),
    Row(
        "/admin/chains", "frontend/app/admin/chains/page.tsx",
        "AdminChainsTable", "enable_chain_toggle", "toggle/switch",
        "useChains.toggleChain", "PUT /api/v1/admin/chains/:id/toggle",
        "ChainToggleRequest", "entrada", "habilita/deshabilita cadena",
        "admin-chains.ts", "PG: chains_runtime + audit",
        "arbx:config:chains:<id>:reload", "searcher-rs",
        "chain_toggled",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "admin-chains.toggle.test", "PASS",
    ),
    Row(
        "/admin/chains", "frontend/app/admin/chains/page.tsx",
        "AdminChainsTable", "edit_chain_form", "form",
        "useChains.editChain", "PUT /api/v1/admin/chains/:id",
        "ChainEditRequest", "entrada", "edita parámetros cadena",
        "admin-chains.ts", "PG: chains_runtime + audit",
        "arbx:config:chains:<id>:reload", "searcher-rs",
        "chain_edited",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "admin-chains.edit.test", "PASS",
    ),
    # ── /dex-registry ────────────────────────────────────────────────────
    Row(
        "/dex-registry", "frontend/app/dex-registry/page.tsx",
        "DexRegistryClient", "create_dex_form", "form",
        "useDexes.create", "POST /api/v1/dexes",
        "DexCreateRequest", "entrada", "agrega DEX a cadena",
        "dexes.ts", "PG: dex_registry + audit",
        "arbx:config:dex:<id>:reload", "searcher-rs scanner",
        "dex_added",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "dexes.test",
        "PARTIAL — `Math.random` para row keys (DexRegistryClient:437) cumple INV (no persistido) pero recomendado reemplazar por crypto.randomUUID",
    ),
    # ── /pools ───────────────────────────────────────────────────────────
    Row(
        "/pools", "frontend/app/pools/page.tsx", "PoolsClient",
        "pool_table", "table", "usePools", "GET /api/v1/pools",
        "PoolEntity[]", "salida", "lista pools con sync status",
        "pools.ts", "PG: pool_registry", "—", "pool_sync_worker", "—",
        "PASS por pool con last_sync_at",
        "pools.test", "PASS",
    ),
    # ── /wallets ─────────────────────────────────────────────────────────
    Row(
        "/wallets", "frontend/app/wallets/page.tsx", "WalletsClient",
        "wallet_table", "table", "useWallets", "GET /api/v1/wallets",
        "WalletEntity[]", "salida", "lista wallets + Ghost balance=0",
        "wallets.ts", "PG: wallet_registry", "—", "—", "—",
        "PASS con balance_wei='0' INV-7",
        "wallets.test", "PASS",
    ),
    # ── /rpcs ────────────────────────────────────────────────────────────
    Row(
        "/rpcs", "frontend/app/rpcs/page.tsx", "RpcsClient",
        "rpc_health_table", "table", "useRpcs", "GET /api/v1/rpcs",
        "RpcEntity[]", "salida", "lista RPCs con latencia p50/p95",
        "—", "PG: rpc_registry", "—", "rpc_health_worker", "—",
        "PASS / UNAVAILABLE si rpc down",
        "rpcs.test", "PASS",
    ),
    # ── /strategies ──────────────────────────────────────────────────────
    Row(
        "/strategies", "frontend/app/strategies/page.tsx",
        "StrategiesClient", "strategy_enable_toggle", "toggle/switch",
        "useStrategies.toggle", "PUT /api/v1/strategies/:id/toggle",
        "StrategyToggleRequest", "entrada",
        "habilita/deshabilita estrategia",
        "strategy-runtime-status.ts", "PG: strategy_registry + audit",
        "arbx:config:strategy:<id>:reload", "spine decision loop",
        "strategy_toggled",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "strategies.test", "PASS",
    ),
    Row(
        "/strategies", "frontend/app/strategies/tabs/DexesTab.tsx",
        "DexesTab", "per_chain_dex_save_button", "button",
        "useTradingConfig.save", "PUT /api/v1/trading-config",
        "TradingConfigRequest", "entrada",
        "guarda config DEX por chain",
        "trading-config.ts", "PG: trading_config", "—", "searcher-rs", "—",
        "PARTIAL_phase3",
        "trading-config.test",
        "PARTIAL — TODO Phase 3: per-chain trading_config rows (DexesTab:11,115)",
    ),
    # ── /risk ────────────────────────────────────────────────────────────
    Row(
        "/risk", "frontend/app/risk/page.tsx", "RiskClient",
        "risk_gate_form", "form", "useRiskGates.set",
        "PUT /api/v1/risk/gates/:id",
        "RiskGateRequest", "entrada", "ajusta umbral de risk gate",
        "risk-circuit-breakers.ts", "PG: risk_gates + audit",
        "arbx:config:risk:<id>:reload", "searcher-rs + spine",
        "risk_gate_updated",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "risk.test", "PASS",
    ),
    Row(
        "/risk", "frontend/app/risk/page.tsx", "RiskClient",
        "circuit_breaker_state", "card", "useCircuitBreakers",
        "GET /api/v1/risk/circuit-breakers",
        "CircuitBreaker[]", "salida",
        "muestra estado CLOSED/HALF_OPEN/OPEN",
        "risk-circuit-breakers.ts", "PG: circuit_breakers",
        "—", "spine breaker engine", "—",
        "PASS / WARNING si OPEN",
        "circuit-breakers.test", "PASS",
    ),
    # ── /killswitch ──────────────────────────────────────────────────────
    Row(
        "/killswitch", "frontend/app/killswitch/page.tsx", "KillswitchClient",
        "engage_killswitch_button", "button", "useKillswitch.engage",
        "POST /api/killswitch/engage",
        "KillswitchRequest (sovereign sig)", "entrada",
        "activa parada de emergencia global",
        "killswitch.ts (configs/killswitch.json)",
        "FS + PG audit", "arbx:killswitch:reload", "searcher-rs + spine",
        "killswitch_engaged",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "killswitch.test", "PASS",
    ),
    # ── /config + /config/trading ────────────────────────────────────────
    Row(
        "/config/trading", "frontend/app/config/trading/page.tsx",
        "TradingConfig", "paper_mode_toggle", "toggle/switch",
        "useTradingConfig.setPaperMode",
        "PUT /api/v1/trading-config/paper-mode",
        "PaperModeRequest", "entrada",
        "paper/live por chain (live requiere sovereign sig)",
        "trading-config.ts", "PG: trading_config + audit",
        "arbx:config:trading:reload", "searcher-rs",
        "paper_mode_changed",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "trading-config.test", "PASS",
    ),
    Row(
        "/config/trading", "frontend/app/config/trading/page.tsx",
        "TradingConfig", "capital_cap_input", "input number",
        "useCapitalGate.setCap",
        "PUT /api/v1/capital-gates/:chain_id",
        "CapitalGateRequest (sovereign sig if >0)",
        "entrada",
        "ajusta cap_usd por chain (default $0.00)",
        "—", "PG: capital_gates + audit",
        "arbx:config:capital:<chain_id>:reload",
        "spine bayesian_allocator",
        "capital_cap_updated",
        "WAITING_RUNTIME_ACK → VERIFIED si sig válida; BLOCKED sin sig",
        "capital-gate.test", "PASS",
    ),
    # ── /settings + /settings/credentials ────────────────────────────────
    Row(
        "/settings", "frontend/app/settings/page.tsx", "SettingsClient",
        "preferences_form", "form", "useUserPrefs",
        "PUT /api/settings/preferences",
        "UserPrefs", "entrada", "preferencias visuales (no operacional)",
        "—", "PG: user_prefs (no operacional)", "—", "—", "—",
        "VERIFIED (no requiere runtime ack)",
        "settings.test", "PASS",
    ),
    Row(
        "/settings/credentials", "frontend/app/settings/credentials/page.tsx",
        "CredentialsClient", "credentials_list", "table",
        "useCredentials", "GET /api/credentials",
        "CredentialMeta[]", "salida",
        "lista credenciales (read-only; rotación CLI)",
        "credentials.ts", "PG: credentials_meta (no secret)", "—", "—", "—",
        "PASS read-only", "credentials.test", "PASS",
    ),
    # ── /worker-health ───────────────────────────────────────────────────
    Row(
        "/worker-health", "frontend/app/worker-health/page.tsx",
        "WorkerHealth", "worker_table", "table", "useWorkerHealth",
        "GET /api/agents/status",
        "AgentTeam[]", "salida",
        "salud de searcher-rs + spine + recon",
        "agents-status.ts", "Redis: agent_heartbeats",
        "—", "agents publish heartbeat", "—",
        "PASS / STALE si heartbeat > 15s",
        "agents-status.test", "PASS",
    ),
    # ── /status ──────────────────────────────────────────────────────────
    Row(
        "/status", "frontend/app/status/page.tsx", "StatusClient",
        "system_heartbeat", "card", "useSystemStatus",
        "GET /api/system/status",
        "SystemStatus", "salida",
        "heartbeat global del sistema",
        "—", "Redis: system_status", "—", "—", "—",
        "PASS / STALE",
        "status.test", "PASS",
    ),
    # ── /opportunities + /recon ──────────────────────────────────────────
    Row(
        "/recon", "frontend/app/recon/page.tsx", "ReconClient",
        "pnl_aggregate", "card", "useRecon", "GET /api/recon/pnl",
        "ReconAggregate", "salida",
        "agrega P&L de ventana de 60s",
        "—", "PG: recon_aggregates", "arbx:scoring:updates:<chain>",
        "spine feedback.rs → bayesian_allocator",
        "—", "PASS",
        "recon.test", "PASS",
    ),
    # ── /omega-s5/core ───────────────────────────────────────────────────
    Row(
        "/omega-s5/core", "frontend/app/omega-s5/core/page.tsx",
        "OmegaS5Core", "manifest_hash", "badge",
        "useSystemManifest", "GET /api/system/manifest",
        "SystemManifest", "salida",
        "muestra hash manifest + features",
        "system-manifest.ts", "PG: feature_manifest",
        "—", "—", "—", "PASS", "manifest.test", "PASS",
    ),
    # ── /omega-s5/adapters ───────────────────────────────────────────────
    Row(
        "/omega-s5/adapters", "frontend/app/omega-s5/adapters/page.tsx",
        "Adapters", "adapter_table", "table", "useAdapters",
        "GET /api/system/manifest",
        "AdapterEntry[]", "salida",
        "lista adapters DEX/flashloan/cross-chain",
        "system-manifest.ts", "PG: feature_manifest",
        "—", "—", "—", "PASS",
        "adapters.test", "PASS",
    ),
    # ── /omega-s5/crucible ───────────────────────────────────────────────
    Row(
        "/omega-s5/crucible", "frontend/app/omega-s5/crucible/page.tsx",
        "Crucible", "crucible_metrics", "card", "useCrucible",
        "GET /api/crucible/status",
        "CrucibleStatus", "salida",
        "muestra ≥72h × ≥95% × 0 reverts no-doctrinales",
        "—", "PG: crucible_runs",
        "—", "—", "—",
        "PASS / BLOCKED si gate no satisfecho",
        "crucible.test", "PASS",
    ),
    # ── /omega-s5/drift ──────────────────────────────────────────────────
    Row(
        "/omega-s5/drift", "frontend/app/omega-s5/drift/page.tsx",
        "DriftDetection", "drift_table", "table", "useDriftDetection",
        "GET /api/drift/events",
        "DriftEvent[]", "salida",
        "lista config_hash mismatch DB↔runtime",
        "—", "PG: drift_events", "—", "drift_watcher", "—",
        "PASS (drift=0) / WARNING",
        "drift.test", "PASS",
    ),
    # ── /omega-s5/factory ────────────────────────────────────────────────
    Row(
        "/omega-s5/factory", "frontend/app/omega-s5/factory/page.tsx",
        "Factory", "deterministic_factory_panel", "card", "useFactory",
        "GET /api/factory/topology",
        "WalletTopology", "salida",
        "muestra DeterministicFactory + topology",
        "—", "PG: wallet_topology", "—", "—", "—",
        "PASS", "factory.test", "PASS",
    ),
    # ── /omega-s5/operator ───────────────────────────────────────────────
    Row(
        "/omega-s5/operator", "frontend/app/omega-s5/operator/page.tsx",
        "OperatorPanel", "operator_role_select", "select/list",
        "useOperator.promote", "POST /api/operator/role/promote",
        "OperatorPromoteRequest (sovereign sig)", "entrada",
        "promueve rol observer → steward → sovereign",
        "operator.ts", "PG: operator_parametrization + audit",
        "arbx:config:operator:reload", "api-server",
        "operator_role_changed",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "operator.test", "PASS",
    ),
    # ── /omega-s5/wallets ────────────────────────────────────────────────
    Row(
        "/omega-s5/wallets", "frontend/app/omega-s5/wallets/page.tsx",
        "OmegaWallets", "topology_view", "card", "useWalletTopology",
        "GET /api/wallets/topology",
        "WalletTopology", "salida",
        "topology de wallets con Ghost balance=0",
        "wallets.ts", "PG: wallet_topology",
        "—", "—", "—",
        "PASS INV-7 verificado", "wallets-topology.test", "PASS",
    ),
    # ── /omega-s5/registry + [entity] ────────────────────────────────────
    Row(
        "/omega-s5/registry", "frontend/app/omega-s5/registry/page.tsx",
        "RegistryHub", "registry_cards_grid", "card", "useRegistries",
        "GET /api/admin/registries",
        "RegistrySummary[]", "salida",
        "hub de 12 registries × 7 capacidades",
        "admin-registries.ts", "PG: registry_*", "—", "—", "—",
        "PASS hub",
        "registries.hub.test", "PASS",
    ),
    Row(
        "/omega-s5/registry/[entity]",
        "frontend/app/omega-s5/registry/[entity]/page.tsx",
        "RegistryDetail", "crud_form", "form", "useRegistry(entity)",
        "POST/PUT/DELETE /api/admin/registries/:entity",
        "RegistryEntity", "entrada+salida",
        "CRUD genérico por entidad (12 entidades)",
        "admin-registries.ts", "PG: registry_<entity> + audit",
        "arbx:config:<entity>:<id>:reload",
        "searcher-rs / spine",
        "registry_entity_<verb>",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "registry.crud.test",
        "PARTIAL — useRegistry.ts:105 tiene `configHash: null` con TODO; debe leer hash real",
    ),
    # ── Onboarding 2/3/4 (resumen) ───────────────────────────────────────
    Row(
        "/onboarding/2-connect", "frontend/app/onboarding/2-connect/page.tsx",
        "OnboardingConnect", "rpc_add_form", "form", "useRpcs.add",
        "POST /api/v1/rpcs", "RpcCreateRequest", "entrada",
        "agrega RPC + health check",
        "—", "PG: rpc_registry + audit",
        "arbx:config:rpc:<id>:reload", "rpc_health_worker",
        "rpc_added",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "onboarding.rpc.test", "PASS",
    ),
    Row(
        "/onboarding/3-advanced", "frontend/app/onboarding/3-advanced/page.tsx",
        "OnboardingAdvanced", "risk_gate_form", "form", "useRiskGates.set",
        "PUT /api/v1/risk/gates/:id", "RiskGateRequest", "entrada",
        "configura risk gates iniciales",
        "risk-circuit-breakers.ts", "PG: risk_gates + audit",
        "arbx:config:risk:<id>:reload", "spine", "risk_gate_set",
        "WAITING_RUNTIME_ACK → VERIFIED",
        "onboarding.risk.test", "PASS",
    ),
    Row(
        "/onboarding/4-testing", "frontend/app/onboarding/4-testing/page.tsx",
        "OnboardingTesting", "crucible_run_monitor", "card", "useCrucible",
        "GET /api/crucible/status", "CrucibleStatus", "salida",
        "monitorea ejecución Crucible en testnets",
        "—", "PG: crucible_runs", "—", "searcher-rs (testnet)", "—",
        "PASS al cumplir gate", "crucible.test", "PASS",
    ),
    # ── /sed ─────────────────────────────────────────────────────────────
    Row(
        "/sed", "frontend/app/sed/page.tsx", "SedClient",
        "sed_core_panel", "card", "useSedCore",
        "GET /api/sed/status", "SedStatus", "salida",
        "muestra signed execution doctrine state",
        "sed-status.ts", "Redis: sed_state", "—", "sed-core (Rust)", "—",
        "PASS",
        "sed.test", "PASS",
    ),
]


def main() -> int:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    columns = [
        "ruta", "archivo", "componente", "elemento_ui", "tipo_elemento",
        "hook_store", "endpoint_ws", "tipo_dato", "entrada_salida",
        "funcion", "backend_handler", "persistencia", "reload_event",
        "runtime_consumer", "audit_event", "ui_final_state", "tests", "estado",
    ]
    with OUT.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        for r in ROWS:
            writer.writerow([
                r.ruta, r.archivo, r.componente, r.elemento_ui, r.tipo_elemento,
                r.hook_store, r.endpoint_ws, r.tipo_dato, r.entrada_salida,
                r.funcion, r.backend_handler, r.persistencia, r.reload_event,
                r.runtime_consumer, r.audit_event, r.ui_final_state, r.tests,
                r.estado,
            ])
    print(f"OK rows={len(ROWS)} out={OUT}")
    # Quick stats
    by_state: dict[str, int] = {}
    for r in ROWS:
        # only the first token before '—'
        key = r.estado.split(" ")[0]
        by_state[key] = by_state.get(key, 0) + 1
    print(f"BY_STATE={by_state}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
